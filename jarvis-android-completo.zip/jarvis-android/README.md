# JARVIS AI (Android)

Projeto Android em Kotlin para Android 8.0+ (minSdk 26), pacote `com.jarvis.ai`.

## Comandos de voz

Com o serviço ativo, diga frases como:
- "Jarvis, abrir WhatsApp"
- "Jarvis, abrir Spotify"
- "Jarvis, abrir YouTube"
- "Jarvis, abrir TikTok"

O aplicativo correspondente precisa estar instalado no celular.

## Como compilar pelo GitHub no celular

1. Envie todos os arquivos desta pasta para a raiz do repositório `jarvis-android`, mantendo as pastas.
2. Faça commit na branch `main`.
3. Abra a aba **Actions** do GitHub.
4. Entre em **Build JARVIS AI APK** e aguarde o workflow terminar.
5. Abra a execução concluída e baixe o artefato **jarvis-ai-debug**.
6. Instale o APK no Android e permita o acesso ao microfone.

## Como ativar

Abra JARVIS AI uma vez e toque em **ATIVAR JARVIS**. Mantenha a notificação do serviço ativa. Para desligar, use o botão **DESATIVAR** ou a ação na notificação.

## Limitações importantes do Android

- O reconhecimento usa o serviço de reconhecimento de fala do Android, não um chip dedicado de palavra de ativação. O consumo de bateria pode ser alto e alguns aparelhos/serviços podem interromper o reconhecimento contínuo.
- A tela pode ficar bloqueada enquanto o serviço estiver ativo, mas o Android pode encerrar o serviço por economia de bateria ou restrições do fabricante.
- Após reiniciar o celular, abra o app e toque em **ATIVAR JARVIS** novamente. O Android restringe iniciar um serviço de microfone automaticamente durante a inicialização.
- O app não grava nem armazena áudio intencionalmente; o reconhecimento depende do serviço de fala configurado no Android e pode usar serviços de rede.

## Configuração técnica

- Kotlin/JVM 17
- compileSdk 35
- targetSdk 35
- minSdk 26
- Android Gradle Plugin 8.7.3
- Kotlin Android plugin 2.0.21
