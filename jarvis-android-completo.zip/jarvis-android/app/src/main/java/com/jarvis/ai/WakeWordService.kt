package com.jarvis.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

class WakeWordService : Service() {

    private var recognizer: SpeechRecognizer? = null
    private var listening = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopListening()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        beginListening()
        return START_STICKY
    }

    private fun beginListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        if (listening) return

        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { speech ->
            speech.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { listening = true }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false }
                override fun onError(error: Int) {
                    listening = false
                    restartListening()
                }
                override fun onResults(results: Bundle?) {
                    listening = false
                    val phrases = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        .orEmpty()
                    phrases.firstOrNull()?.let { handlePhrase(it) }
                    restartListening()
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val phrases = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        .orEmpty()
                    phrases.firstOrNull()?.let { phrase ->
                        if (phrase.contains("jarvis", ignoreCase = true)) {
                            handlePhrase(phrase)
                        }
                    }
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        startRecognition()
    }

    private fun startRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try {
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            listening = false
            restartListening()
        }
    }

    private fun restartListening() {
        recognizer?.let { speech ->
            try { speech.cancel() } catch (_: Exception) {}
        }
        listening = false
        // SpeechRecognizer is not a guaranteed always-on hotword engine.
        // A short delayed restart avoids recursively restarting inside callbacks.
        android.os.Handler(mainLooper).postDelayed({
            if (!listening && recognizer != null) startRecognition()
        }, 900)
    }

    private fun handlePhrase(raw: String) {
        val phrase = raw.lowercase(Locale("pt", "BR"))
        if (!phrase.contains("jarvis")) return

        val packageName = when {
            phrase.contains("whatsapp") -> "com.whatsapp"
            phrase.contains("spotify") -> "com.spotify.music"
            phrase.contains("youtube") || phrase.contains("you tube") ->
                "com.google.android.youtube"
            phrase.contains("tiktok") || phrase.contains("tik tok") ->
                "com.zhiliaoapp.musically"
            else -> null
        } ?: return

        try {
            val launch = packageManager.getLaunchIntentForPackage(packageName)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launch)
            }
        } catch (_: Exception) {
            // App is not installed or Android prevented the launch.
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "JARVIS - reconhecimento de voz",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Mostra quando o reconhecimento de voz do JARVIS está ativo."
            }
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, WakeWordService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingStop = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS AI está ativo")
            .setContentText("Diga: Jarvis, abrir WhatsApp, Spotify, YouTube ou TikTok.")
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    android.graphics.drawable.Icon.createWithResource(
                        this, android.R.drawable.ic_media_pause
                    ),
                    "Desativar",
                    pendingStop
                ).build()
            )
            .build()
    }

    private fun stopListening() {
        try { recognizer?.cancel() } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        listening = false
    }

    override fun onDestroy() {
        stopListening()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "jarvis_voice_channel"
        private const val NOTIFICATION_ID = 39
        private const val ACTION_STOP = "com.jarvis.ai.STOP"
    }
}
